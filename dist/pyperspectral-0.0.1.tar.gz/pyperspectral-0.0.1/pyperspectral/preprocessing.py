
def derivative():
    pass


# TODO: - Smoothing
#       - Derivative
#       - Normalisation
#       - mean center
