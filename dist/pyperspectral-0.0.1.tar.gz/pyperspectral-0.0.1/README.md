# HSI.py
## Description