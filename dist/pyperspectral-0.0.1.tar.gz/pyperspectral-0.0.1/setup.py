from setuptools import setup
import pyperspectral

setup(
    name='pyperspectral',
    version=pyperspectral.__version__,
    packages=['pyperspectral'],
    url='',
    license='',
    author='Roland Pfeiffer',
    author_email='',
    description=''
)
